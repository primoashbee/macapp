<?php 
 header('Access-Control-Allow-Origin: *');
require "config.php";
session_start();
session_destroy();
?>
